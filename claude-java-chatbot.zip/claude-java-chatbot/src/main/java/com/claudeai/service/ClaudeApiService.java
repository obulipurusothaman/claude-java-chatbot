package com.claudeai.service;

import com.claudeai.config.ClaudeConfig;
import com.claudeai.model.Conversation;
import com.claudeai.model.Message;
import com.google.gson.*;
import okhttp3.*;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * ClaudeApiService — handles all HTTP communication with the Anthropic API.
 *
 * Docs: https://docs.anthropic.com/en/api/messages
 */
public class ClaudeApiService {

    private final OkHttpClient httpClient;
    private final Gson         gson;
    private final String       apiKey;

    public ClaudeApiService() {
        this.apiKey = ClaudeConfig.getApiKey();
        this.gson   = new GsonBuilder().setPrettyPrinting().create();

        // Build HTTP client with sensible timeouts
        this.httpClient = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();
    }

    /**
     * Send the full conversation to Claude and get its reply.
     *
     * @param conversation  the current conversation (all turns so far)
     * @return              Claude's text response
     * @throws IOException  on network or API errors
     */
    public String chat(Conversation conversation) throws IOException {
        String  requestBody = buildRequestBody(conversation);
        Request request     = buildHttpRequest(requestBody);

        try (Response response = httpClient.newCall(request).execute()) {
            String responseBody = response.body() != null
                    ? response.body().string() : "";

            if (!response.isSuccessful()) {
                throw new IOException(parseApiError(response.code(), responseBody));
            }

            return parseResponseText(responseBody);
        }
    }

    // ─── Request Building ────────────────────────────────────────────────────

    private String buildRequestBody(Conversation conversation) {
        JsonObject body = new JsonObject();
        body.addProperty("model",      ClaudeConfig.DEFAULT_MODEL);
        body.addProperty("max_tokens", ClaudeConfig.DEFAULT_MAX_TOKENS);
        body.addProperty("system",     ClaudeConfig.SYSTEM_PROMPT);

        // Build messages array from conversation history
        JsonArray messagesArray = new JsonArray();
        for (Message msg : conversation.getMessages()) {
            JsonObject msgObj = new JsonObject();
            msgObj.addProperty("role",    msg.getRole());
            msgObj.addProperty("content", msg.getContent());
            messagesArray.add(msgObj);
        }
        body.add("messages", messagesArray);

        return gson.toJson(body);
    }

    private Request buildHttpRequest(String jsonBody) {
        RequestBody body = RequestBody.create(
                jsonBody, MediaType.parse("application/json; charset=utf-8")
        );

        return new Request.Builder()
                .url(ClaudeConfig.API_BASE_URL + ClaudeConfig.MESSAGES_ENDPOINT)
                .addHeader("x-api-key",         apiKey)
                .addHeader("anthropic-version",  ClaudeConfig.API_VERSION)
                .addHeader("content-type",       "application/json")
                .post(body)
                .build();
    }

    // ─── Response Parsing ────────────────────────────────────────────────────

    private String parseResponseText(String responseBody) throws IOException {
        try {
            JsonObject json    = JsonParser.parseString(responseBody).getAsJsonObject();
            JsonArray  content = json.getAsJsonArray("content");

            if (content == null || content.isEmpty()) {
                throw new IOException("API returned empty content array.");
            }

            // Find the first text block
            for (JsonElement element : content) {
                JsonObject block = element.getAsJsonObject();
                if ("text".equals(block.get("type").getAsString())) {
                    return block.get("text").getAsString().trim();
                }
            }

            throw new IOException("No text block found in API response.");

        } catch (JsonParseException e) {
            throw new IOException("Failed to parse API response: " + e.getMessage());
        }
    }

    private String parseApiError(int statusCode, String responseBody) {
        try {
            JsonObject json  = JsonParser.parseString(responseBody).getAsJsonObject();
            JsonObject error = json.getAsJsonObject("error");
            String     msg   = error != null
                    ? error.get("message").getAsString()
                    : responseBody;
            return String.format("API Error %d: %s", statusCode, msg);
        } catch (Exception e) {
            return String.format("API Error %d: %s", statusCode, responseBody);
        }
    }
}
