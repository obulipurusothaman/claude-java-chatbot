package com.claudeai.config;

/**
 * Configuration for the Claude AI API.
 * Set your API key via environment variable: ANTHROPIC_API_KEY
 */
public class ClaudeConfig {

    // ─── Claude API Constants ───────────────────────────────────────────────
    public static final String API_BASE_URL      = "https://api.anthropic.com";
    public static final String MESSAGES_ENDPOINT = "/v1/messages";
    public static final String API_VERSION       = "2023-06-01";

    // Model to use — claude-sonnet-4-20250514 is the recommended default
    public static final String DEFAULT_MODEL     = "claude-sonnet-4-20250514";

    // Max tokens in Claude's response
    public static final int    DEFAULT_MAX_TOKENS = 1024;

    // System prompt — define Claude's behaviour here
    public static final String SYSTEM_PROMPT =
        "You are a helpful, friendly assistant. " +
        "Answer clearly and concisely. " +
        "If you are unsure about something, say so honestly.";

    // ─── Read API Key from environment ──────────────────────────────────────
    public static String getApiKey() {
        String key = System.getenv("ANTHROPIC_API_KEY");
        if (key == null || key.isBlank()) {
            throw new IllegalStateException(
                "Missing API key! Set the environment variable: ANTHROPIC_API_KEY\n" +
                "  Linux/Mac: export ANTHROPIC_API_KEY=your-key-here\n" +
                "  Windows:   set ANTHROPIC_API_KEY=your-key-here\n" +
                "Get your key at: https://console.anthropic.com/"
            );
        }
        return key;
    }
}
