package com.claudeai.cli;

import com.claudeai.model.Conversation;
import com.claudeai.service.ClaudeApiService;

import java.io.IOException;
import java.util.Scanner;

/**
 * ChatbotApp — the main entry point for the Claude AI CLI Chatbot.
 *
 * Run with:
 *   export ANTHROPIC_API_KEY=your-key-here
 *   java -jar claude-chatbot.jar
 *
 * Commands:
 *   /history  — print full conversation history
 *   /clear    — start a new conversation
 *   /help     — show available commands
 *   /quit     — exit the chatbot
 */
public class ChatbotApp {

    // ANSI colour codes for a nicer terminal experience
    private static final String RESET  = "\u001B[0m";
    private static final String BOLD   = "\u001B[1m";
    private static final String CYAN   = "\u001B[36m";
    private static final String GREEN  = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";
    private static final String RED    = "\u001B[31m";
    private static final String BLUE   = "\u001B[34m";

    private final ClaudeApiService apiService;
    private final Conversation     conversation;
    private final Scanner          scanner;

    public ChatbotApp() {
        this.apiService   = new ClaudeApiService();
        this.conversation = new Conversation();
        this.scanner      = new Scanner(System.in);
    }

    public static void main(String[] args) {
        new ChatbotApp().run();
    }

    public void run() {
        printWelcomeBanner();

        while (true) {
            // Prompt user
            System.out.print(BOLD + CYAN + "\nYou: " + RESET);
            String input = scanner.nextLine().trim();

            if (input.isEmpty()) continue;

            // Handle slash commands
            if (input.startsWith("/")) {
                if (handleCommand(input)) break; // /quit returns true
                continue;
            }

            // Send message to Claude
            sendMessage(input);
        }

        printGoodbye();
    }

    // ─── Message Handling ────────────────────────────────────────────────────

    private void sendMessage(String userInput) {
        conversation.addUserMessage(userInput);

        System.out.print(BOLD + GREEN + "\nClaude: " + RESET);
        System.out.println(YELLOW + "Thinking..." + RESET);

        try {
            String reply = apiService.chat(conversation);
            conversation.addAssistantMessage(reply);

            // Reprint label then show response
            System.out.print("\u001B[1A\u001B[2K"); // clear "Thinking..." line
            System.out.println(BOLD + GREEN + "Claude: " + RESET + reply);

        } catch (IOException e) {
            // Remove message we added since it failed
            conversation.clear(); // Or you could remove just the last message

            System.out.println(RED + "Error: " + e.getMessage() + RESET);
            System.out.println(YELLOW + "Your message was not saved. Please try again." + RESET);
        }
    }

    // ─── Command Handling ────────────────────────────────────────────────────

    /**
     * @return true if the app should exit
     */
    private boolean handleCommand(String command) {
        switch (command.toLowerCase()) {
            case "/quit", "/exit", "/q" -> {
                return true;
            }
            case "/clear", "/new" -> {
                conversation.clear();
                System.out.println(GREEN + "✓ Conversation cleared. Starting fresh!" + RESET);
            }
            case "/history", "/h" -> {
                conversation.printHistory();
            }
            case "/help", "/?" -> {
                printHelp();
            }
            default -> {
                System.out.println(RED + "Unknown command: " + command + RESET);
                System.out.println("Type " + BOLD + "/help" + RESET + " to see available commands.");
            }
        }
        return false;
    }

    // ─── UI Helpers ──────────────────────────────────────────────────────────

    private void printWelcomeBanner() {
        System.out.println();
        System.out.println(BOLD + BLUE + "╔══════════════════════════════════════════════╗" + RESET);
        System.out.println(BOLD + BLUE + "║       Claude AI CLI Chatbot  (Java)          ║" + RESET);
        System.out.println(BOLD + BLUE + "║       Powered by Anthropic API               ║" + RESET);
        System.out.println(BOLD + BLUE + "╚══════════════════════════════════════════════╝" + RESET);
        System.out.println();
        System.out.println("  Type your message and press " + BOLD + "Enter" + RESET + " to chat.");
        System.out.println("  Type " + BOLD + "/help" + RESET + " to see available commands.");
        System.out.println();
    }

    private void printHelp() {
        System.out.println();
        System.out.println(BOLD + "Available Commands:" + RESET);
        System.out.println("  " + CYAN + "/history" + RESET + "  — View the full conversation history");
        System.out.println("  " + CYAN + "/clear"   + RESET + "    — Clear history and start a new conversation");
        System.out.println("  " + CYAN + "/help"    + RESET + "     — Show this help message");
        System.out.println("  " + CYAN + "/quit"    + RESET + "     — Exit the chatbot");
        System.out.println();
    }

    private void printGoodbye() {
        System.out.println();
        System.out.println(BOLD + GREEN + "Goodbye! Thanks for chatting with Claude. 👋" + RESET);
        System.out.println();
    }
}
