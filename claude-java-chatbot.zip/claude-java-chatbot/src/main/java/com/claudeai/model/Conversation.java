package com.claudeai.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Manages the conversation history for multi-turn chat.
 * Claude needs the full history on every API call to maintain context.
 */
public class Conversation {

    private final List<Message> messages = new ArrayList<>();

    /** Add a user message */
    public void addUserMessage(String content) {
        messages.add(new Message("user", content));
    }

    /** Add an assistant (Claude) message */
    public void addAssistantMessage(String content) {
        messages.add(new Message("assistant", content));
    }

    /** Get all messages (immutable view) */
    public List<Message> getMessages() {
        return Collections.unmodifiableList(messages);
    }

    /** Clear conversation history */
    public void clear() {
        messages.clear();
    }

    /** Number of turns so far */
    public int size() {
        return messages.size();
    }

    /** Print the full conversation to stdout */
    public void printHistory() {
        System.out.println("\n══════════════════════════════════════════");
        System.out.println("  Conversation History (" + size() / 2 + " turns)");
        System.out.println("══════════════════════════════════════════");
        if (messages.isEmpty()) {
            System.out.println("  (empty)");
        } else {
            messages.forEach(m -> System.out.println("  " + m));
        }
        System.out.println("══════════════════════════════════════════\n");
    }
}
