package com.claudeai.model;

/**
 * Represents a single message in the conversation (user or assistant).
 */
public class Message {

    private final String role;    // "user" or "assistant"
    private final String content; // the text content

    public Message(String role, String content) {
        this.role    = role;
        this.content = content;
    }

    public String getRole()    { return role; }
    public String getContent() { return content; }

    @Override
    public String toString() {
        return String.format("[%s]: %s", role.toUpperCase(), content);
    }
}
