package com.claudeai.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ConversationTest {

    @Test
    void testAddAndRetrieveMessages() {
        Conversation conv = new Conversation();
        conv.addUserMessage("Hello Claude!");
        conv.addAssistantMessage("Hi there! How can I help?");

        assertEquals(2, conv.size());
        assertEquals("user",      conv.getMessages().get(0).getRole());
        assertEquals("assistant", conv.getMessages().get(1).getRole());
    }

    @Test
    void testClearConversation() {
        Conversation conv = new Conversation();
        conv.addUserMessage("test");
        conv.clear();

        assertEquals(0, conv.size());
        assertTrue(conv.getMessages().isEmpty());
    }

    @Test
    void testMessageContent() {
        Conversation conv = new Conversation();
        conv.addUserMessage("What is 2+2?");

        assertEquals("What is 2+2?", conv.getMessages().get(0).getContent());
    }

    @Test
    void testImmutableView() {
        Conversation conv = new Conversation();
        conv.addUserMessage("hello");

        assertThrows(UnsupportedOperationException.class, () ->
            conv.getMessages().add(new Message("user", "hack!"))
        );
    }
}
